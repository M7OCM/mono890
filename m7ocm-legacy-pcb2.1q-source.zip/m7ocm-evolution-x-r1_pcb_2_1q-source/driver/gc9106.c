/* GalaxyCore GC9106 TFT LCD controller driver
 * Copyright 2026 M7OCM
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

#include "driver/delay.h"
#include "driver/pins.h"
#include "driver/gc9106.h"

// Physical RAM offset of GC9106 panel
#define LCD_X_OFFSET   0
#define LCD_Y_OFFSET   0

// ---------------------------------------------------------
// Bit-banged SPI (same as original ST7735S driver)
// ---------------------------------------------------------
static void SendByte(uint8_t Data)
{
    for (uint8_t i = 0; i < 8; i++) {
        if (Data & 0x80U) {
            gpio_bits_set(GPIOA, BOARD_GPIOA_LCD_SDA);
        } else {
            gpio_bits_reset(GPIOA, BOARD_GPIOA_LCD_SDA);
        }

        gpio_bits_reset(GPIOA, BOARD_GPIOA_LCD_SCL);
        gpio_bits_set(GPIOA, BOARD_GPIOA_LCD_SCL);

        Data <<= 1;
    }
}

// ---------------------------------------------------------
// GC9106 low-level command/data
// ---------------------------------------------------------
void gc9106_write_cmd(uint8_t cmd)
{
    gpio_bits_reset(GPIOF, BOARD_GPIOF_LCD_DCX); // DC low
    gpio_bits_reset(GPIOC, BOARD_GPIOC_LCD_CS);  // CS low

    SendByte(cmd);

    gpio_bits_set(GPIOC, BOARD_GPIOC_LCD_CS);    // CS high
    gpio_bits_set(GPIOF, BOARD_GPIOF_LCD_DCX);   // DC high
}

void gc9106_write_data(uint8_t data)
{
    gpio_bits_reset(GPIOC, BOARD_GPIOC_LCD_CS);  // CS low

    SendByte(data);

    gpio_bits_set(GPIOC, BOARD_GPIOC_LCD_CS);    // CS high
}

// ---------------------------------------------------------
// Coordinate mapping (UI → GC9106 physical RAM)
// ---------------------------------------------------------
static inline void gc9106_map_xy(uint16_t x, uint16_t y,
                                 uint16_t *px, uint16_t *py)
{
    *px = x + LCD_X_OFFSET;
    *py = y + LCD_Y_OFFSET;
}

// ---------------------------------------------------------
// GC9106 windowing (CASET = X, RASET = Y)
// ---------------------------------------------------------
void gc9106_set_window(uint16_t x, uint16_t y,
                       uint16_t w, uint16_t h)
{
    uint16_t x0 = x;
    uint16_t y0 = y;
    uint16_t x1 = x + w - 1;
    uint16_t y1 = y + h - 1;

    uint16_t px0, py0, px1, py1;
    gc9106_map_xy(x0, y0, &px0, &py0);
    gc9106_map_xy(x1, y1, &px1, &py1);

    gc9106_write_cmd(0x2A); // CASET (X)
    gc9106_write_data(px0 >> 8);
    gc9106_write_data(px0 & 0xFF);
    gc9106_write_data(px1 >> 8);
    gc9106_write_data(px1 & 0xFF);

    gc9106_write_cmd(0x2B); // RASET (Y)
    gc9106_write_data(py0 >> 8);
    gc9106_write_data(py0 & 0xFF);
    gc9106_write_data(py1 >> 8);
    gc9106_write_data(py1 & 0xFF);

    gc9106_write_cmd(0x2C); // RAMWR
}

// ---------------------------------------------------------
// Panel-specific tuning, taken from GalaxyCore's own reference
// init code (GC9106-SPI初始程序.c) for this glass. B4h/F0h/F1h
// (and the undocumented B3h) all require Inter_command to be
// latched high via FEh+EFh first, or the writes are ignored --
// see restrictions under 6.3.1/6.2.33/6.3.14/6.3.15 of the
// datasheet.
//
// Note: the datasheet's SET_GAMMA1/SET_GAMMA2 tables list 15
// parameters each, but the vendor's own working reference code
// sends only 14 data bytes per command (verified by counting the
// actual writes in the sample). Reproduced exactly as shipped
// rather than padded to match the "preliminary" datasheet table.
// ---------------------------------------------------------
static const uint8_t gc9106_gamma_pos[14] = {
    0x31, 0x4C, 0x24, 0x58, 0xA8, 0x26, 0x28,
    0x00, 0x2C, 0x0C, 0x0C, 0x15, 0x15, 0x0F,
};

static const uint8_t gc9106_gamma_neg[14] = {
    0x0E, 0x2D, 0x24, 0x3E, 0x99, 0x12, 0x13,
    0x00, 0x0A, 0x0D, 0x0D, 0x14, 0x13, 0x0F,
};

void gc9106_apply_vendor_tuning(void)
{
    uint8_t i;

    gc9106_write_cmd(0xFE); // Inner register enable 1
    gc9106_write_cmd(0xEF); // Inner register enable 2

    gc9106_write_cmd(0xB3); // Undocumented panel-tuning register
    gc9106_write_data(0x03); // (present in every vendor reference init)

    gc9106_write_cmd(0xB4); // Display Inversion Control
    gc9106_write_data(0x21); // 1-dot inversion (panel-tuned; POR default is column inversion)

    gc9106_write_cmd(0xF0); // SET_GAMMA1 (positive)
    for (i = 0; i < sizeof(gc9106_gamma_pos); i++) {
        gc9106_write_data(gc9106_gamma_pos[i]);
    }

    gc9106_write_cmd(0xF1); // SET_GAMMA2 (negative)
    for (i = 0; i < sizeof(gc9106_gamma_neg); i++) {
        gc9106_write_data(gc9106_gamma_neg[i]);
    }
}

// ---------------------------------------------------------
// High-level init/draw API (LCD_Init, LCD_FillRect, LCD_DrawPixel,
// LCD_BlitBitmap) originally lived here as a standalone GC9106 API.
// It was superseded by wiring these low-level primitives directly
// into the existing ST7735S_* API (see driver/st7735s.c), so the
// rest of the firmware needs no GC9106-specific code path. Retained
// here: the bring-up primitives that file depends on.
// ---------------------------------------------------------
