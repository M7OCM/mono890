/* GalaxyCore GC9106 TFT LCD controller driver
 * Copyright 2026 M7OCM
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

#include "driver/delay.h"
#include "driver/pins.h"
#include "driver/st7735s.h"
#include "driver/gc9106.h"

// GC9106 physical panel parameters
#define LCD_WIDTH      128
#define LCD_HEIGHT     160

// No GRAM offset is required on the production GC9106 panel.
// Earlier -1 testing offset was only a visual aid; exact-length
// stream windows align the GC9106 pixel-perfect with the ST7735S.
#define LCD_X_OFFSET   0
#define LCD_Y_OFFSET   0

static inline uint16_t gc9106_clamp_coord(int32_t v, uint16_t exclusive_max)
{
    if (v < 0) {
        return 0;
    }
    if (v >= (int32_t)exclusive_max) {
        return (uint16_t)(exclusive_max - 1);
    }
    return (uint16_t)v;
}

// Orientation and pixel format used by the ST7735S-compatible UI mapping.
#define LCD_MADCTL     0x48
#define LCD_COLMOD     0x05    // RGB565

// ---------------------------------------------------------
// ST7735S API implemented using GC9106 backend
// ---------------------------------------------------------

void ST7735S_SendCommand(ST7735S_Command_t Command)
{
    // ST7735S command values are reused; only CASET/RASET/RAMWR
    // need remapping to GC9106 equivalents.
    switch (Command) {
    case 0x2A: // CASET
        gc9106_write_cmd(0x2A);
        break;
    case 0x2B: // RASET
        gc9106_write_cmd(0x2B);
        break;
    case 0x2C: // RAMWR
        gc9106_write_cmd(0x2C);
        break;
    default:
        gc9106_write_cmd(Command);
        break;
    }
}

void ST7735S_SendData(uint8_t Data)
{
    gc9106_write_data(Data);
}

void ST7735S_SendU16(uint16_t Data)
{
    gc9106_write_data((Data >> 8) & 0xFF);
    gc9106_write_data((Data >> 0) & 0xFF);
}

/*
 * The UI uses the original 160x128 ST7735S coordinate system.
 * Map it onto the physical 128x160 GC9106 panel:
 *
 *   rx = Y
 *   ry = LCD_HEIGHT - 1 - X
 *
 * Fixed-length pixel streams must use ST7735S_SetPositionRun().
 * GC9106 requires the address window to match the number of pixels
 * streamed; oversized ST7735S-style windows corrupt glyphs/icons.
 */

void ST7735S_SetPosition(uint8_t X, uint8_t Y)
{
    uint16_t rx = gc9106_clamp_coord((int32_t)LCD_X_OFFSET + Y, LCD_WIDTH);
    uint16_t ry = gc9106_clamp_coord((int32_t)LCD_Y_OFFSET + (LCD_HEIGHT - 1 - X), LCD_HEIGHT);
    uint16_t run = (rx < LCD_WIDTH) ? (LCD_WIDTH - rx) : 1;

    gc9106_set_window(rx, ry, run, 1);
}

/* Open an exact-length horizontal GRAM window for streamed bitmap columns. */
void ST7735S_SetPositionRun(uint8_t X, uint8_t Y, uint8_t Length)
{
    uint16_t rx = gc9106_clamp_coord((int32_t)LCD_X_OFFSET + Y, LCD_WIDTH);
    uint16_t ry = gc9106_clamp_coord((int32_t)LCD_Y_OFFSET + (LCD_HEIGHT - 1 - X), LCD_HEIGHT);
    uint16_t run = Length;

    if (run == 0)
        run = 1;
    if ((uint16_t)(rx + run) > LCD_WIDTH)
        run = LCD_WIDTH - rx;

    gc9106_set_window(rx, ry, run, 1);
}

void ST7735S_SetPixel(uint8_t X, uint8_t Y, uint16_t Color)
{
    uint16_t rx = gc9106_clamp_coord((int32_t)LCD_X_OFFSET + Y, LCD_WIDTH);
    uint16_t ry = gc9106_clamp_coord((int32_t)LCD_Y_OFFSET + (LCD_HEIGHT - 1 - X), LCD_HEIGHT);

    gc9106_set_window(rx, ry, 1, 1);
    gc9106_write_data(Color >> 8);
    gc9106_write_data(Color & 0xFF);
}

/*
 * Rectangle mapping: UI rectangle (x0..x1, y0..y1) must be rotated
 * into GC9106 space. This is used by higher-level fill/bitmap code.
 *
 * UI space:  X: 0..159, Y: 0..127
 * GC9106:    128x160, rotated via MADCTL.
 *
 * We rotate 90° clockwise:
 *   (x, y) -> (rx, ry) = (Y, LCD_HEIGHT - 1 - X)
 */

void ST7735S_SetAddrWindow(uint8_t x0, uint8_t y0,
                           uint8_t x1, uint8_t y1)
{
    uint16_t rx0 = gc9106_clamp_coord((int32_t)LCD_X_OFFSET + y0, LCD_WIDTH);
    uint16_t ry0 = gc9106_clamp_coord((int32_t)LCD_Y_OFFSET + (LCD_HEIGHT - 1 - x1), LCD_HEIGHT);

    uint16_t rx1 = gc9106_clamp_coord((int32_t)LCD_X_OFFSET + y1, LCD_WIDTH);
    uint16_t ry1 = gc9106_clamp_coord((int32_t)LCD_Y_OFFSET + (LCD_HEIGHT - 1 - x0), LCD_HEIGHT);

    uint16_t x_start = (rx0 < rx1) ? rx0 : rx1;
    uint16_t y_start = (ry0 < ry1) ? ry0 : ry1;

    uint16_t w = (rx0 < rx1) ? (rx1 - rx0 + 1) : (rx0 - rx1 + 1);
    uint16_t h = (ry0 < ry1) ? (ry1 - ry0 + 1) : (ry0 - ry1 + 1);

    gc9106_set_window(x_start, y_start, w, h);
}

// ---------------------------------------------------------
// Init sequence for GC9106, exposed as ST7735S_Init
// ---------------------------------------------------------
void ST7735S_Init(void)
{
    // Hardware reset timing follows the GalaxyCore reference init.
    gpio_bits_set(GPIOF, BOARD_GPIOF_LCD_RESX);
    DELAY_WaitMS(120);
    gpio_bits_reset(GPIOF, BOARD_GPIOF_LCD_RESX);
    DELAY_WaitMS(100);
    gpio_bits_set(GPIOF, BOARD_GPIOF_LCD_RESX);
    DELAY_WaitMS(120);

    // Panel tuning (gamma, inversion scheme, undocumented B3h) must be
    // set up before Sleep Out so the DC/DC converters power up already
    // using the correct values, matching the vendor-recommended order.
    gc9106_apply_vendor_tuning();

    gc9106_write_cmd(0x36); // MADCTL
    gc9106_write_data(LCD_MADCTL);

    gc9106_write_cmd(0x3A); // COLMOD
    gc9106_write_data(LCD_COLMOD);

    gc9106_write_cmd(0x21); // Display inversion ON

    gc9106_write_cmd(0x11); // Sleep Out
    DELAY_WaitMS(120);

    gc9106_write_cmd(0x29); // Display ON
    DELAY_WaitMS(20);

    // Clear screen to black in rotated space.
    // UI thinks in 160x128, so we clear that virtual area.
    ST7735S_SetAddrWindow(0, 0, 159, 127);

    for (uint32_t i = 0; i < (LCD_WIDTH * LCD_HEIGHT); i++) {
        gc9106_write_data(0x00);
        gc9106_write_data(0x00);
    }
}

// Scroll functions: no-op for GC9106
void ST7735S_defineScrollArea(uint16_t x, uint16_t x2)
{
    (void)x;
    (void)x2;
}

void ST7735S_scroll(uint8_t line)
{
    (void)line;
}
