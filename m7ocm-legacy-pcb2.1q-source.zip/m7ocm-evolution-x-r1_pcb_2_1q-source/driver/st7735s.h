/* ST7735S-compatible display API, implemented on the GC9106 backend
 * Copyright 2026 M7OCM
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

#ifndef ST7735S_H
#define ST7735S_H

#include <stdint.h>
#include "driver/gc9106.h"

typedef uint8_t ST7735S_Command_t;

// Public API expected by UI code
void ST7735S_Init(void);
void ST7735S_SetPixel(uint8_t X, uint8_t Y, uint16_t Color);
void ST7735S_SendU16(uint16_t Data);
void ST7735S_SendCommand(ST7735S_Command_t Command);
void ST7735S_SendData(uint8_t Data);
void ST7735S_SetPosition(uint8_t X, uint8_t Y);
void ST7735S_SetPositionRun(uint8_t X, uint8_t Y, uint8_t Length);
void ST7735S_SetAddrWindow(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1);

// Scroll functions (no‑op for GC9106)
void ST7735S_defineScrollArea(uint16_t x, uint16_t x2);
void ST7735S_scroll(uint8_t line);

#endif
