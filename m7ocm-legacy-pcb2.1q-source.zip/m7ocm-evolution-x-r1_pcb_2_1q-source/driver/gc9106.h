/* GalaxyCore GC9106 TFT LCD controller driver
 * Copyright 2026 M7OCM
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

#ifndef GC9106_H
#define GC9106_H

#include <stdint.h>

// Low-level primitives and shared panel bring-up, used by st7735s.c's
// GC9106-backed implementation of the legacy ST7735S API. There is no
// separate GC9106 drawing API -- ST7735S_* (driver/st7735s.h) is the
// only display interface the rest of the firmware uses.
void gc9106_write_cmd(uint8_t cmd);
void gc9106_write_data(uint8_t data);
void gc9106_set_window(uint16_t x, uint16_t y, uint16_t w, uint16_t h);
void gc9106_apply_vendor_tuning(void);

#endif
