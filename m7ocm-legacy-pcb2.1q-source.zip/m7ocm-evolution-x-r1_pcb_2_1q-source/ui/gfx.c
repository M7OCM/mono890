/* Copyright 2023 Dual Tachyon
 * https://github.com/DualTachyon
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

#include "driver/st7735s.h"
#include "misc.h"
#include "ui/gfx.h"

uint16_t gColorForeground;
uint16_t gColorBackground;

uint16_t COLOR_BACKGROUND;
uint16_t COLOR_FOREGROUND;
uint16_t COLOR_RED;
uint16_t COLOR_GREEN;
uint16_t COLOR_BLUE;
uint16_t COLOR_GREY;

void DISPLAY_FillColor(uint16_t Color)
{
	uint32_t i;

	// Full 160x128 UI-space window in one shot, then a single flat
	// burst. The previous version opened a window via
	// ST7735S_SetPosition(0,0), which per its own design is only ever
	// one row tall, then tried to stream 20480 pixels into it. Per
	// GC9106's documented column/page wraparound rules, once that one
	// row fills, the counter has nowhere else to go -- the window's
	// own page range was just that single row -- so it kept
	// re-filling row 159 instead of ever reaching the other 159 rows.
	// This never actually cleared the whole screen. Using the real 2D
	// window here instead.
	ST7735S_SetAddrWindow(0, 0, 159, 127);
	for (i = 0; i < (160UL * 128UL); i++) {
		ST7735S_SendU16(Color);
	}
}

void DISPLAY_Fill(uint8_t X0, uint8_t X1, uint8_t Y0, uint8_t Y1, uint16_t Color)
{
	uint32_t count = (uint32_t)(X1 - X0 + 1) * (uint32_t)(Y1 - Y0 + 1);

	// One window covering the whole rectangle, one flat burst --
	// instead of the previous per-column loop, which opened a fresh
	// window (fresh CASET/RASET/RAMWR command sequence) for every
	// single column and only ever burst more than 1 pixel when the
	// rectangle was taller than it was wide. Every horizontal line,
	// divider, status bar, and S-meter pip is wider than tall, so
	// none of them ever got a real multi-pixel burst -- each pixel
	// was an isolated, one-off write. Multi-pixel bursts through one
	// open window are the pattern that's confirmed working
	// everywhere else (glyphs, vertical lines); this makes fills use
	// that same pattern regardless of the rectangle's shape.
	ST7735S_SetAddrWindow(X0, Y0, X1, Y1);
	while (count--) {
		ST7735S_SendU16(Color);
	}
}

void DISPLAY_DrawRectangle0(uint8_t X, uint8_t Y, uint8_t W, uint8_t H, uint16_t Color)
{
	DISPLAY_Fill(X, X + W - 1, Y, Y + H - 1, Color);
}

void DISPLAY_DrawRectangle1(uint8_t X, uint8_t Y, uint8_t H, uint8_t W, uint16_t Color)
{
	DISPLAY_Fill(X, X + W - 1, Y, Y + H - 1, Color);
}

void UI_SetColors(uint8_t DarkMode)
{
	if (DarkMode) {
		COLOR_BACKGROUND = COLOR_RGB( 0,  0,  0);
		COLOR_FOREGROUND = COLOR_RGB(31, 63, 31);
		
	} else {
		COLOR_BACKGROUND = COLOR_RGB(31, 63, 31);
		COLOR_FOREGROUND = COLOR_RGB( 0,  0,  0);

	}
	COLOR_RED   = COLOR_RGB(28,  9,  4);
	COLOR_GREEN = COLOR_RGB( 9, 52,  4);
	COLOR_BLUE  = COLOR_RGB( 4,  9, 28);
	COLOR_GREY  = COLOR_RGB(16, 32, 16);
	//COLOR_WHITE  = COLOR_RGB(31, 63, 31);

	gColorBackground = COLOR_BACKGROUND;
	gColorForeground = COLOR_FOREGROUND;
	
	DISPLAY_FillColor(COLOR_BACKGROUND);
}

