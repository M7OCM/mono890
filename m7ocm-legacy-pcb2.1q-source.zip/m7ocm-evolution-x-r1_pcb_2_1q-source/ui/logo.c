/* Copyright 2023 Dual Tachyon
 * https://github.com/DualTachyon
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

#include "driver/delay.h"
#include "driver/serial-flash.h"
#include "driver/st7735s.h"
#include "misc.h"
#include "ui/gfx.h"
#include "ui/logo.h"

static void DrawImage(uint32_t Address)
{
    uint16_t i;
    // X now runs 0->159 in natural source order (was: started at 159,
    // decremented). That "right-to-left" compensation was tuned for
    // MADCTL=0xC8 (MY=1). Dropping to 0x48 (MY=0) flips the hardware's
    // own row-address direction on this same axis, so the old
    // software compensation now fights the hardware instead of
    // correcting it -- removing it is what should un-mirror the logo
    // again under the new MADCTL value.
    uint8_t X = 0;
    uint8_t Y = 0;

    for (i = 0; i < 0x7800; i += 2) {
        uint16_t Color;

        if ((i & 0x1FFF) == 0) {
            SFLASH_Read(gFlashBuffer, Address + i, sizeof(gFlashBuffer));
        }

        Color = (gFlashBuffer[i & 0x1FFF] << 8) | gFlashBuffer[(i + 1) & 0x1FFF];

        ST7735S_SetPixel(X, Y, Color);

        if (X == 159) {
            X = 0;
            Y++;
        } else {
            X++;
        }
    }
}

void UI_DrawLogo(void)
{
	DrawImage(0x3B5000);
	DELAY_WaitMS(2000);
}
